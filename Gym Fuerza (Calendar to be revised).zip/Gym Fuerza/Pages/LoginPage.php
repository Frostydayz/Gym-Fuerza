<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Connecting
    $connect = new mysqli('localhost', 'root', '', 'gym_fuerza');

    if ($connect->connect_error) {
        die("Connection failed: " . $connect->connect_error);
    }

    $selectQuery = "SELECT Username, Password FROM security WHERE Username = ?";
    $FetchLogin = $connect->prepare($selectQuery);
    $FetchLogin->bind_param("s", $username);
    $FetchLogin->execute();
    $UserAndPass = $FetchLogin->get_result();

    if ($UserAndPass->num_rows == 1) {
        $user_data = $UserAndPass->fetch_assoc();
        $hashingPass = $user_data['Password'];
        $hashed_password = password_hash($hashingPass, PASSWORD_DEFAULT);

        if (password_verify($password, $hashed_password)) {
            
            echo '<script>alert("Logged In Succesfully!");</script>';

            $_SESSION["username"] = $username;
            $_SESSION["logged_in"] = true;
            header("Location: HomePage.php");
            exit();
        } else {
            echo '<script>alert("Incorrect username or password!");</script>';
        }
    } else {
        echo '<script>alert("Incorrect username or password!");</script>';
    }

    $FetchLogin->close();
    $connect->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="../CSS/Login.css">
</head>
<body>
    <div id="Login">
        <div id="LoginInner">
            <img src="../Images/Logo.png" id="Logo">
            <h1>Welcome Back</h1>
            <form action="" method="post">
                <p>Username*</p>
                <input type="text" id="username" placeholder="Enter Username" name="username" required>
                <p>Password*</p>
                <input type="password" id="password" placeholder="Enter Password" name="password" required>
                <br><br>
                <input type="submit" id="Submit" value="Login">
                <hr>
            </form>
        </div>
    </div>
</body>
</html>
