<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../CSS/SalesReport.css">
</head>
<body>
    <?php
        include("Header.php");
    ?>

    <table>
        <?php
            include("../PHP/tblSales.php");
        ?>
    </table>
</body>
</html> 