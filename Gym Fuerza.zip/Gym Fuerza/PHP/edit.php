<?php
$id = $_POST['id'];
$Name = $_POST['Name'];
$Discount = $_POST['D_Type'];
$Membership = $_POST['M_Type'];
$DiscountID = 0;

if ($Membership == "Member" && $Discount == "Students") {
    $DiscountID = 1;
} else if ($Membership == "Member" && $Discount == "Regulars") {
    $DiscountID = 2;
} else if ($Membership == "Non-Member" && $Discount == "Students") {
    $DiscountID = 3;
} else {
    $DiscountID = 4;  
}

// Connecting
$connect = new mysqli('localhost', 'root', '', 'gym_fuerza');

if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

$SelectName = "SELECT GymGoerID FROM gymgoer WHERE Name = ? AND GymGoerID != ?";
$CheckName = $connect->prepare($SelectName);
$CheckName->bind_param("si", $Name, $id);
$CheckName->execute();
$CheckName->store_result();
$num_rows = $CheckName->num_rows;

if ($num_rows > 0) {
    echo '<script>alert("A member with the same name already exists."); window.history.back();</script>';
    exit;
} else {
    $CheckName->free_result();

    $SelectCurrentName = "SELECT Name FROM gymgoer WHERE GymGoerID = ?";
    $CheckCurrentName = $connect->prepare($SelectCurrentName);
    $CheckCurrentName->bind_param("i", $id);
    $CheckCurrentName->execute();
    $CheckCurrentName->bind_result($CurrentName);
    $CheckCurrentName->fetch();
    $CheckCurrentName->close(); 

    if ($CurrentName !== $Name || $DiscountID != $Discount) {
        $Update = "UPDATE gymgoer SET Name = ?, DiscountID = ? WHERE GymGoerID = ?";
        $Edit = $connect->prepare($Update);
        $Edit->bind_param("sii", $Name, $DiscountID, $id);
        $Edit->execute();
        $Edit->close();
    }
}

header("Location: ../Pages/MembersPage.php");
exit;

$connect->close();
?>
