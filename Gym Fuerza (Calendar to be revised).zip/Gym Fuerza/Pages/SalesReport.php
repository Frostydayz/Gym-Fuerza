<?php
session_start();

function checkCode() {
    if (!isset($_SESSION["AccessCode"]) ||!isset($_SESSION["View_Sales"])) {
        echo '<script>alert("Direct Link wont work here"); window.history.back();</script>';
        exit();
    }
}

checkCode();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../CSS/SalesReport.css">
</head>
<body>
    <?php
        include("Header.php");
    ?>

    <table>
        <?php
            include("../PHP/tblSales.php");
        ?>
    </table>
</body>
</html> 