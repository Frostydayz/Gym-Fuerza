<?php
//connecting
$connect = new mysqli('localhost', 'root', '', 'gym_fuerza');

//Declare variables
$Name = $_POST['NameAdd'];
$SelectDiscount = $_POST['DiscountAdd'];
$Discount = 0;

if ($SelectDiscount == "Students") {
    $Discount = 1;
}

else {
    $Discount = 2;
}


// Check if the name exists in gymgoer table
$checkExisting = $connect->prepare("SELECT GymGoerID, DiscountID FROM gymgoer WHERE Name = ?");
$checkExisting->bind_param("s", $Name);
$checkExisting->execute();
$checkExisting->store_result();
$count = $checkExisting->num_rows;
$checkExisting->bind_result($gymGoerID, $existingDiscountID);
$checkExisting->fetch();
$checkExisting->close();

if ($count > 0) {
    echo '<script>alert("Member already exists"); window.history.back();</script>';
} else {
$InsertQuery = "INSERT INTO gymgoer(Name, DiscountID) VALUES (?, ?)";
$AddMember = $connect->prepare($InsertQuery);
$AddMember->bind_param("si", $Name, $Discount);  
$AddMember->execute();
$AddMember->close();
header ("Location: ../Pages/MembersPage.php");
}
?>