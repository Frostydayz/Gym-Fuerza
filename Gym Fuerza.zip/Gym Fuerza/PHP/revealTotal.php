<?php
session_start();

// Connecting
$mysqli = new mysqli('localhost', 'root', '', 'gym_fuerza');
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accessCode = $_POST['AccessTotal'];
    
    $selectcode = "SELECT AccessCode FROM security WHERE AccessCode = ?";
    $fetchCode = $mysqli->prepare($selectcode);
    $fetchCode->bind_param("s", $accessCode);
    $fetchCode->execute();
    $result = $fetchCode->get_result();
    
    if ($result->num_rows == 1) {
        $_SESSION['access_code_valid'] = true;
    } else {
        echo '<script>alert("Invalid access code. Please try again."); window.history.back();</script>';
        exit;
    }
    
    $fetchCode->close();
}

$mysqli->close();
?>
