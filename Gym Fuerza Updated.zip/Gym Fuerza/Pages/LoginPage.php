<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="../CSS/Login.css">
</head>
<body>
    <?php
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        // retrieve form data
        $username = $_POST['username'];
        $password = $_POST['password'];

        $SqlPass = '';
        // Create connection to database
        $connect = new mysqli('localhost', 'root', $SqlPass, 'gym_fuerza');

        // Check connection
        if ($connect->connect_error) {
            die("Connection failed: " . $connect->connect_error);
        }

        // validate login authentication using prepared statement
        $selectQuery = "SELECT * FROM security WHERE Username = ? AND password = ?";
        $FetchLogin = $connect->prepare($selectQuery);
        $FetchLogin->bind_param("ss", $username, $password);
        $FetchLogin->execute();
        $UserAndPass = $FetchLogin->get_result();

        if ($UserAndPass->num_rows == 1) {
            // Login successful
            echo '<script type="text/javascript">alert("Logged In!");</script>';
            header("Location: HomePage.php");
            exit();
        } else {
            // Login failed
            echo '<script type="text/javascript">alert("INCORRECT USERNAME OR PASSWORD!");</script>';
        }

        $connect->close();
    }
    ?>
    <div id="Login">
        <div id="LoginInner">
            <img src="../Images/Logo.png" id="Logo">
            <h1>Welcome Back</h1>
            <form action="" method="post">
                <p>Email Address*</p>
                <input type="text" id="username" placeholder="Enter Username" name="username" required>
                <p>Password*</p>
                <input type="password" id="password" placeholder="Enter Password" name="password" required>
                <br><br>
                <input type="submit" id="Submit" value="Login">
                <hr>
            </form>
        </div>
    </div>
</body>
</html>
