
<style>
#accessModal {
    position:absolute;
    top: 0;
    left: 0;
    z-index: 999;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 0, 0, 0.5);
    display: none;
}

#formAccess {
    border: 2px white solid;
    color: white;
    background-color: #162736;
    height: 200px;
    width: 330px;
    position: fixed;
    left: 40%;
    top: 40%;
    padding: 1%;
    border-radius: 20px;
    align-items: center;
    text-align: center;
    justify-content: center;
}

.Close, .Confirm {
    width: 70px;
    height: 25px;
    font-size: 16px;
    background-color: rgb(6, 145, 8);
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
    color: white;
    border: none;
    border-bottom: black 3px solid;
    border-right: black 2px solid;
    border-radius: 2px; 
    margin: 1em;
}

</style>

<script>
    function DisplayTime() {
        const dateTime = new Date();
        const hour = dateTime.getHours();
        const minute = dateTime.getMinutes();

        if (minute < 10) {
            document.getElementById("CurrentTime").innerHTML = hour + " : 0" + minute;
        } else {
            document.getElementById("CurrentTime").innerHTML = hour + " : " + minute;
        }
    }

    function GetTime() {
        const dateTime = new Date();
        const hour = dateTime.getHours();
        const minute = dateTime.getMinutes();

        if (minute < 10) {
            document.getElementById("Toime").innerHTML = hour + " : 0" + minute;
        } else {
            document.getElementById("Toime").innerHTML = hour + " : " + minute;
        }
    }

    function DisplayMonthDate() {
        const dateTime = new Date();
        const monthIndex = dateTime.getMonth();
        const monthName = getMonthName(monthIndex);
        const date = dateTime.getDate();

        document.getElementById("CurrentDate").innerHTML = monthName + " " + date;
    }

    function getMonthName(monthIndex) {
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        return monthNames[monthIndex];
    }

    function DisplayDay() {
        const dateTime = new Date();
        const DayNumber = dateTime.getDay();

        const DayName = [
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
        ];

        document.getElementById("CurrentDay").innerText = DayName[DayNumber];
    }

    window.onload = function() {
        DisplayDay();
        DisplayTime();
        DisplayMonthDate();
        
        setInterval(DisplayDay, 60000);
        setInterval(DisplayTime, 1000);
        setInterval(DisplayMonthDate, 60000);
    }

    function openModal() {
        document.getElementById("accessModal").style.display = "block";
    }

    function closeModal() {
        document.getElementById("accessModal").style.display = "none";
    }

    function handleLinkClick(event) {
        event.preventDefault();
    }

</script>


<link rel="stylesheet" href="../CSS/Header.css">
<div id="Header">
    <div id="LocaleTime">
        <div> 
            <p id="CurrentDay"></p>
        </div>
        <div class="TimeBox">
            <p id="CurrentTime"></p>
        </div>
        <div>
            <p id="CurrentDate"></p>
        </div>
    </div>
    <nav id="navbar">
        <a href ="HomePage.php">Homepage</a>
        <a href ="Calendar.php">Calendar</a>
        <a href ="MembersPage.php">Members</a>
        <a href ="" id="openModal" onclick="openModal(); return false">Sales</a>
    </nav>
</div>
</div>


<div id="accessModal">
    <form action="" method="post" id="formAccess">
        <h2>Enter Access Code to Access Sales</h2>
        <input type="password" name="AccessCode" id="AccessCode">
        <br>
        <button type="button" onclick="closeModal()" class="Close">Cancel</button>

        <input type="submit" class="Confirm" value="Confirm">

    </form>
</div>


<?php
//connection
$mysqli = new mysqli('localhost', 'root', '', 'gym_fuerza');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accessCode = $_POST['AccessCode'];
    
    $selectcode = "SELECT AccessCode FROM security WHERE AccessCode = '$accessCode'";
    $fetchCode = $mysqli->prepare($selectcode);
    $fetchCode->execute();
    $result = $fetchCode->get_result();
    
    if ($result->num_rows == 1) {
        echo '<script>alert("Access code accepted!"); window.location.href = "SalesReport.php";</script>';
        exit;
    } else {
        echo '<script>alert("Invalid access code. Please try again."); window.history.back();</script>';
        exit;
    }
    
    $fetchCode->close();
}
$mysqli->close();
?>
